extends Node3D

const CITY_RADIUS := 4
const BLOCK_SIZE := 34.0
const ROAD_WIDTH := 12.0
var car: CharacterBody3D
var speed := 0.0
var steering := 0.0
var camera_out: Camera3D
var camera_in: Camera3D
var hud_speed: Label
var touch_accel := false
var touch_brake := false
var touch_left := false
var touch_right := false
var max_speed := 27.0

func _ready() -> void:
	_build_world()
	_build_car()
	_build_ui()
	camera_out.make_current()

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.sky.sky_material = ProceduralSkyMaterial.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.88)
	env.ambient_light_energy = 0.8
	world_env.environment = env
	add_child(world_env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.15
	add_child(sun)
	var ground := _box(Vector3(0, -0.7, 0), Vector3(390, 1, 390), Color(0.18, 0.38, 0.22), true)
	add_child(ground)
	for i in range(-CITY_RADIUS, CITY_RADIUS + 1):
		var p := float(i) * BLOCK_SIZE
		var road_x := _box(Vector3(p, -0.12, 0), Vector3(ROAD_WIDTH, 0.22, 390), Color(0.12, 0.13, 0.15), false)
		add_child(road_x)
		var road_z := _box(Vector3(0, -0.11, p), Vector3(390, 0.22, ROAD_WIDTH), Color(0.12, 0.13, 0.15), false)
		add_child(road_z)
		for side in [-1, 1]:
			var curb_x := _box(Vector3(p + side * ROAD_WIDTH * 0.56, 0.02, 0), Vector3(0.55, 0.35, 390), Color(0.58, 0.58, 0.55), false)
			var curb_z := _box(Vector3(0, 0.02, p + side * ROAD_WIDTH * 0.56), Vector3(390, 0.35, 0.55), Color(0.58, 0.58, 0.55), false)
			add_child(curb_x)
			add_child(curb_z)
	for i in range(-CITY_RADIUS, CITY_RADIUS + 1):
		var p := float(i) * BLOCK_SIZE
		for j in range(-CITY_RADIUS, CITY_RADIUS):
			var z := (float(j) + 0.5) * BLOCK_SIZE
			var x := (float(i) + 0.5) * BLOCK_SIZE
			if abs(x) < 175 and abs(z) < 175:
				_add_building(Vector3(x, 0, z), 9.0 + float((i*3+j*7+40) % 6) * 2.2, 11.0 + float((i+j*2+30) % 4) * 4.0)
	# Simple dashed lane markers
	for i in range(-1, 2):
		var p := float(i) * BLOCK_SIZE
		for k in range(-10, 11):
			var d := float(k) * 10.0
			var mark1 := _box(Vector3(p, 0.015, d), Vector3(0.18, 0.035, 4.2), Color(0.88, 0.85, 0.68), false)
			var mark2 := _box(Vector3(d, 0.016, p), Vector3(4.2, 0.035, 0.18), Color(0.88, 0.85, 0.68), false)
			add_child(mark1)
			add_child(mark2)

func _add_building(pos: Vector3, width: float, height: float) -> void:
	var colors := [Color("#8b9ba7"), Color("#c1aa8e"), Color("#87958c"), Color("#b7b9bd"), Color("#9b8f9f")]
	var idx := int(abs(pos.x * 3.0 + pos.z * 7.0)) % colors.size()
	var body := _box(pos + Vector3(0, height * 0.5, 0), Vector3(width, height, width), colors[idx], true)
	add_child(body)
	var roof := _box(pos + Vector3(0, height + 0.35, 0), Vector3(width + 0.5, 0.7, width + 0.5), Color(0.28, 0.31, 0.34), false)
	add_child(roof)
	# Window bands on the road-facing side
	for y in range(2, int(height) - 1, 3):
		var strip := _box(pos + Vector3(0, float(y), width * 0.505), Vector3(width * 0.78, 0.65, 0.08), Color(0.25, 0.48, 0.62), false)
		add_child(strip)

func _build_car() -> void:
	car = CharacterBody3D.new()
	car.name = "PlayerCar"
	car.position = Vector3(0, 0.65, 5)
	add_child(car)
	var car_shape := CollisionShape3D.new()
	var car_box := BoxShape3D.new()
	car_box.size = Vector3(2.1, 1.2, 4.0)
	car_shape.shape = car_box
	car.add_child(car_shape)
	var chassis := _box(Vector3(0, 0.0, 0), Vector3(2.15, 0.58, 4.2), Color("#e2b52d"), false)
	car.add_child(chassis)
	var cabin := _box(Vector3(0, 0.52, -0.18), Vector3(1.55, 0.72, 1.9), Color("#263e52"), false)
	car.add_child(cabin)
	var hood := _box(Vector3(0, 0.23, -1.45), Vector3(1.8, 0.16, 1.05), Color("#f0c43a"), false)
	car.add_child(hood)
	for x in [-1.08, 1.08]:
		for z in [-1.35, 1.35]:
			var wheel := _cylinder(Vector3(x, -0.25, z), 0.36, 0.24, Color("#17191d"))
			wheel.rotation_degrees.z = 90
			car.add_child(wheel)
	var head_l := _box(Vector3(-0.62, 0.05, -2.12), Vector3(0.42, 0.12, 0.08), Color("#fff2bd"), false)
	var head_r := _box(Vector3(0.62, 0.05, -2.12), Vector3(0.42, 0.12, 0.08), Color("#fff2bd"), false)
	car.add_child(head_l); car.add_child(head_r)
	camera_out = Camera3D.new()
	camera_out.position = Vector3(0, 4.3, 8.5)
	camera_out.rotation_degrees = Vector3(-17, 0, 0)
	camera_out.fov = 76
	car.add_child(camera_out)
	camera_in = Camera3D.new()
	camera_in.position = Vector3(0, 1.18, -0.18)
	camera_in.rotation_degrees = Vector3(-4, 0, 0)
	camera_in.fov = 84
	car.add_child(camera_in)

func _physics_process(delta: float) -> void:
	var accel := Input.is_action_pressed("accelerate") or touch_accel
	var brake := Input.is_action_pressed("brake") or touch_brake
	var left := Input.is_action_pressed("steer_left") or touch_left
	var right := Input.is_action_pressed("steer_right") or touch_right
	if accel:
		speed = move_toward(speed, max_speed, 13.0 * delta)
	elif brake:
		# Brake smoothly to a stop; do not unexpectedly put the car into reverse.
		speed = move_toward(speed, 0.0, 22.0 * delta)
	else:
		speed = move_toward(speed, 0.0, 4.5 * delta)
	var target_steer := 0.0
	if left: target_steer += 1.0
	if right: target_steer -= 1.0
	steering = move_toward(steering, target_steer, 3.2 * delta)
	if abs(speed) > 0.15:
		car.rotate_y(steering * 1.25 * delta * sign(speed) * clamp(abs(speed) / 9.0, 0.25, 1.0))
	var forward := -car.global_transform.basis.z
	car.velocity = forward * speed
	car.velocity.y = -0.5
	car.move_and_slide()
	if hud_speed:
		hud_speed.text = "গতি: %d km/h" % int(abs(speed) * 3.6)

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_tree().quit()
	if event is InputEventKey and event.pressed and event.keycode == KEY_C:
		_toggle_camera()

func _toggle_camera() -> void:
	if camera_out.current:
		camera_in.make_current()
	else:
		camera_out.make_current()

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var ui := Control.new()
	ui.name = "MobileHUD"
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(ui)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 16)
	panel.size = Vector2(210, 56)
	ui.add_child(panel)
	hud_speed = Label.new()
	hud_speed.text = "গতি: 0 km/h"
	hud_speed.add_theme_font_size_override("font_size", 22)
	panel.add_child(hud_speed)
	var cam := Button.new()
	cam.text = "ক্যামেরা"
	cam.position = Vector2(18, 84)
	cam.size = Vector2(132, 54)
	cam.pressed.connect(_toggle_camera)
	ui.add_child(cam)
	# Anchor driving controls to the bottom corners so they remain visible
	# on phones with different landscape resolutions and aspect ratios.
	_add_hold_button(ui, "◀", false, Vector2(24, -102), "left")
	_add_hold_button(ui, "▶", false, Vector2(112, -102), "right")
	_add_hold_button(ui, "ব্রেক", true, Vector2(-200, -102), "brake")
	_add_hold_button(ui, "গ্যাস", true, Vector2(-104, -102), "accel")

func _add_hold_button(ui: Control, caption: String, from_right: bool, offset: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = caption
	b.size = Vector2(78, 78)
	b.add_theme_font_size_override("font_size", 22)
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	if from_right:
		b.anchor_left = 1.0
		b.anchor_right = 1.0
	b.offset_left = offset.x
	b.offset_top = offset.y
	b.offset_right = offset.x + 78
	b.offset_bottom = offset.y + 78
	ui.add_child(b)
	b.button_down.connect(func(): _set_touch(action, true))
	b.button_up.connect(func(): _set_touch(action, false))

func _set_touch(action: String, value: bool) -> void:
	match action:
		"left": touch_left = value
		"right": touch_right = value
		"brake": touch_brake = value
		"accel": touch_accel = value

func _box(pos: Vector3, size: Vector3, color: Color, collision: bool) -> Node3D:
	var root: Node3D = StaticBody3D.new() if collision else MeshInstance3D.new()
	root.position = pos
	var mesh := BoxMesh.new()
	mesh.size = size
	if root is MeshInstance3D:
		var mi := root as MeshInstance3D
		mi.mesh = mesh
		mi.material_override = _mat(color)
	else:
		var body := root as StaticBody3D
		var mi := MeshInstance3D.new()
		mi.mesh = mesh
		mi.material_override = _mat(color)
		body.add_child(mi)
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = size
		shape.shape = box
		body.add_child(shape)
	return root

func _cylinder(pos: Vector3, radius: float, height: float, color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.position = pos
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	m.mesh = mesh
	m.material_override = _mat(color)
	return m

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.72
	return m
